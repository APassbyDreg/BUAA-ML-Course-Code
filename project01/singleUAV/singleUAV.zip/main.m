%% 地图信息
N=20; %地图细分格数N*N，地图上点范围在[0,1]*[0,1]
N2=50; %计算积分时地图细分的格数
EPISOD_SUM=20*N;
K=20;  %威胁系数

%% 无人机信息
INITIAL =[.1 .05];  %逃逸起始点
OBSER_RADIS=0.2;    %观察半径0<x<1
stepWay=0.02;       %无人机一次运动的距离

%% 初始化
enemysUK = enemyGuass(); %ememyGuass为已定义函数，导入敌人数据,归结为未知的敌人队列
enemysK = []; %已知敌人队列为空
enemysUK2plot = enemyGuass(); %ememyGuass为已定义函数，导入敌人数据,归结为未知的敌人队列
TARGET = round([0.9 0.9] * N); %round为取整函数，遵循四舍五入。TARGET为终点
pos = INITIAL; %INITIAL为起始位置，将其赋值给pos，定为UAV起始位置,在0到1之间。而pos为当前plan的位置，会随着无人机行进而变化
traceRecord = [];
needRePlan = 1; %需要重新规划标记位,当遇到一个新敌人时置一重新规划一次路径
imgnum = 0; %主循环while进行的次数

%% 创建数据保存文件夹
dirname = ['single_K_', num2str(K), '_pos1_', num2str(INITIAL(1, 1)), '_', num2str(INITIAL(1, 2)), '_N_', num2str(N)];
mkdir('.\pic\', dirname);

tic; %计时开始

while (~isequal(round(pos * N), TARGET))%%当当前无人机位置与目标位置不同时，则无人机前行
    imgnum = imgnum + 1; %%前行次数加一
    %% 进行一次路径规划(在遇到新的敌人，即敌人队列发生变化时才进行此部分的操作，此部分即算的是R矩阵，从而决定Q矩阵)
    if (needRePlan == 1)
        needRePlan = 0;
        disp('replanning...');
        E = Ematrix(N2, enemysK); %%调用Ematrix函数，并将所得值赋给E，Ematrix是用来计算当前所探知的敌人所构成威胁区域的函数，N2和enemysK分别为：用来积分的地图细分格数，已知的敌人序列
        TRACE = planning(round(pos * N), TARGET, E, N, EPISOD_SUM, K); %%调用planning函数，planning函数是用来，round（pos*N）为当前位置，TARGET是目标位置，E是前一步用Ematrix算出的值，N为地图细分格数，EPISOD_SUM，K是威胁系数
    end

    %%此步骤中给出的TRACE为在当前敌人背景下所规划出的行走方案，由下一个部分来具体实施
    %% 决定下一个运动到的位置（此部分在上一部分确定此时的敌人所决定的R和Q矩阵后，对每一步进行选择）
    if (isequal(round(pos * N), TRACE(1, 1:2)))
        TRACE(1, :) = []; %%如果第一行已经走到了，那么去掉第一行，从第二行开始走，以此类推
    end

    tgoal = TRACE(1, 1:2) / N; %%将步骤序列中的位置值标准化
    dis = norm(tgoal - pos); %%计算一下当前位置和要求位置间的距离

    if (dis > stepWay)%%stepWay是一次无人机运动的距离
        pos = pos + (tgoal - pos) * stepWay / dis; %%此次即移动到这个新的位置，移动的步长小于一个stepWay
    else
        pos = tgoal; %%要是本身就小于一个步长，则直接移动到这里
    end

    traceRecord = cat(1, traceRecord, pos); %%记录运动到的位置,带参数1的cat函数指的是[traceRecord;pos],即排成了一列

    %%traceRecord即为每一步的记录，将所有的算在一起，即为所有的行走方案
    %% 判断有无看到新的威胁（此部分即用来判定是否遇到了新的敌人）
    i = 1;

    while (i <= size(enemysUK, 1))%%size函数返回矩阵enemysUK的行数，而enemysUK是全部的敌人的函数，表示搜寻所有的敌人，从第一行搜寻到最后一行

        if (norm(enemysUK(i, 1:2) - pos) < OBSER_RADIS)%%如果敌人威胁中心和当前位置之间的距离小于观察半径，则考虑之
            enemysK = cat(1, enemysK, enemysUK(i, 1:3)); %%考虑的意思就是将观察到的enemysUK加入enemyK之中，以列的形式排放
            enemysUK(i, :) = []; %%此行即设为空
            needRePlan = 1; %%需要重新规划
        else
            i = i + 1;
        end

    end

    %% 保存图像
    if (mod(imgnum, 5) == 0)
        drawBackground;
        saveas(gcf, ['.\pic\', dirname, '\', 'img', num2str(imgnum)], 'emf');
    end

    close all;
end

t = toc; %计时结束

%% 保存最终图像
drawBackground;
saveas(gcf,['.\pic\',dirname,'\','finish_t=',num2str(t),'s'],'emf');