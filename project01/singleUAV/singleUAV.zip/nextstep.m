function [s3,dis] = nextstep(s1,s2,dis0)   
    %%s1是规范化后的随机s值，s2是规范化后的位置值，dis0是参考量
    %NEXTSTEP Summary of this function goes here
    %   Detailed explanation goes here
    dis=norm(s1-s2);                                %%计算s1和s2间的距离
    if dis0>dis                                     %%若s1和s2之间距离足够小，则s3直接返回s2的值，即位置规范值，dis返回s1和s2之间的距离
        s3=s2;
    else                                            %%若s1和s2之间距离大，则s3返回s1的值，加上s1和s2之间的距离值的修正值，且dis返回dis0标准值。这里很像mainUAV函数里的第二部分的移动，其需要满足每次的移动
        s3=s1+(s2-s1)*dis0/dis;                     %%的步伐大小小于步长。  
        dis=dis0;
    end
end

