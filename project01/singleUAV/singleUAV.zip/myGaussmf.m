function [E] = myGaussmf(e, para)
%myGaussmy - Description
%
% Syntax: [E] = myGaussmy(e, para)
%
% Long description
    gVar = para(1);
    gAvg = para(2);
    [nrow, ncol] = size(e);
    E = zeros(nrow, ncol);

    parfor r=1:nrow
        E(r, :) = exp(- (e(r, :) - gAvg) .* (e(r, :) - gAvg) / (2 * gVar * gVar));
    end

end