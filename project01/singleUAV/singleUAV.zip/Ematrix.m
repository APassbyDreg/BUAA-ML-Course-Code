function [E]= Ematrix(N, e)
    eNum=size(e,1);                   %%返回矩阵e的行数
    E=zeros(N,N);                     %%设E为N乘N的零矩阵
    for i=1:eNum                      %%从1到矩阵e的最后一行开始第一层循环
        td=zeros(N,N);                %%每层的td都是N乘N的零矩阵
        for x=1:N                     %%再从1到N进行第二层循环，x表示行
            for y=1:N                 %%从1到N进行第三层循环，y表示列
                td(x,y)=norm([x/N-e(i,1) y/N-e(i,2)]); %%td矩阵的第x行，第y列的值为x/N-e(i,1)和y/N-e(i,2)的距离
            end
        end
        te = myGaussmf(td,[e(i,3) 0]);    %%每个敌人所构成的威胁区域函数
        E = 1-(1-E).*(1-te);            %%考虑了所有敌人之后构成的当前威胁区域函数
    end
end
