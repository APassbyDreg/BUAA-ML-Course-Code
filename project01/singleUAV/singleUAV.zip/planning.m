function [ TRACE ] = planning( INITIAL,TARGET,E,N,EPISOD_SUM,K)
    %PLANNING Summary of this function goes here
    %   Detailed explanation goes here
    %%
    D=ones(N,N)*N*N;                         %%D是N乘N的全1矩阵，并乘以了N^2系数
    D(TARGET(1),TARGET(2))=0;                %%TARGET（1）和TARGET（2）分别是目的地的X坐标和Y坐标，D矩阵中此项为零
    s=TARGET;                                %%将目的地TARGET赋值给s
    for t=1:EPISOD_SUM                       %%大循环的迭代次数
        A=dangerMatrix(s,N,E,K);             %%调用dangerMatrix函数，将值赋给A，返回值A是一个N乘N的矩阵，此函数中s为目的地，N为地图细分格数，E为当前观测到的所有敌人构成的全局威胁域，K为威胁系数
        D=min(D,D(s(1),s(2))+A);             %%min函数用来找D和改造后的A每一项较小的值，将所有较小的一起构成新矩阵，依然赋值给D.D(s(1),s(2))是D矩阵第s（1）行，s（2）列的值，将A矩阵所有元素都要加上这个值
        s=randi(N,1,2);                      %%随机在开区间（0，N）之间形成1*2的整数矩阵
    end

    %%最后得到的D矩阵中的每一项，都是到下一步中最小的值，但不知道是到哪一个地方

    %% 根据W矩阵计算出路径
    step=1;
    s=INITIAL;

    TRACE=[];
    while(~isequal(s,TARGET) && step<N*2)  %%只要s和目的地TARGET不相等，或者所进行的步骤数小于上限2N，则继续进行planning
        step=step+1;
        A2=dangerMatrix(s,N,E,K);            %%计算出对于每一步s的权值矩阵A2
        W2=D+A2;                             %%从s点出发的权值矩阵加上之前已经算过的每一个点到其它点的最小权值矩阵，即可得新的W2
        W2(s(1),s(2))=min(min(W2))*1.1;      %%为了不让s点依然为最小的点
        [a,b]=min(W2);                       %%a返回W2每列的最小值，b返回每列最小值的行号
        [~,d]=min(a);                        %%d返回向量a的最小值的列号
        s(1)=b(d);                           %%从而s1和s2分别是W2最小值的行号和列号
        s(2)=d;
        TRACE=cat(1,TRACE,s);                %%将所要移动的位置排成一列
    end
    if(step>=N*2);disp('stopped by too many steps!');end
end

