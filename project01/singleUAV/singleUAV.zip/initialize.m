% %% 初始化
% enemysUK=enemyGuass();        %ememyGuass为已定义函数，导入敌人数据,归结为未知的敌人队列
% enemysK=[];                   %已知敌人队列为空
% enemysUK2plot =enemyGuass();  %ememyGuass为已定义函数，导入敌人数据,归结为未知的敌人队列
% TARGET = round([0.9 0.9]*N ); %round为取整函数，遵循四舍五入。TARGET为终点
% pos=INITIAL;                  %INITIAL为起始位置，将其赋值给pos，定为UAV起始位置,在0到1之间。而pos为当前plan的位置，会随着无人机行进而变化
% traceRecord=[];
% needRePlan=1;                 %需要重新规划标记位,当遇到一个新敌人时置一重新规划一次路径
% imgnum=0;                     %主循环while进行的次数
% %% 创建数据保存文件夹
% dirname=['single_K_',num2str(K),'_pos1_',num2str(INITIAL(1,1)),'_',num2str(INITIAL(1,2)),'_N_',num2str(N)];
% mkdir('.\pic\',dirname);

% moved to main