N2=50;                                                                           %%计算积分时地图细分的格数

TARGET2plot=[0.895,0.898];                                                       %%终点

hold on
E=Ematrix(N2,enemysUK2plot);
[X,Y]=meshgrid(linspace(0,1,N2),linspace(0,1,N2));                               %%X和Y分别是N2乘N2的矩阵
contour(X,Y,E','DisplayName','E');
xlabel('x');                                                                     %%x和y轴加上x和y标记
ylabel('y'); 
axis([ 0 1.02 0 1.02]);
set(gcf,'Position',[900 300 450 400]);
tr=cat(1,INITIAL,traceRecord);
trSize=size(tr,1);
plot(tr(:,1),tr(:,2),'r','LineWidth',2);
plot(INITIAL(1),INITIAL(2),'ko','LineWidth',2,'MarkerSize',10);
plot(tr(trSize,1),tr(trSize,2),'ko','LineWidth',1,'MarkerSize',6);
plot(TARGET2plot(1),TARGET2plot(2),'kx','LineWidth',2,'MarkerSize',10);

line([0.1 0.3],[0.9 0.9],'LineWidth',2)
line([0.1 0.1],[0.88 0.92],'LineWidth',2)
line([0.3 0.3],[0.88 0.92],'LineWidth',2)
text(0.11,0.87,'Observation')
text(0.11,0.83,'Radius')