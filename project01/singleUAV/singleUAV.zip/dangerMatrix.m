function [tempA]=dangerMatrix(s,N,E,K)       
    %%此函数中s为1*2的从0到N的随机整数矩阵，N为地图细分格数，E为当前观测到的所有敌人构成的全局威胁域，K为威胁系数
    %DANGERMATRIX Summary of this function goes here
    %%此函数的作用为对于随机选择的地图上的一个起点s，以及当前所观测到的敌人威胁矩阵E，对地图上所有点建立到此点的权值更新，即距离+威胁系数乘以距离
    %   Detailed explanation goes here
    N2=size(E,1);                                %%N2是E的行数
    stepdis=1/N2;                                %%步长
    tempA=zeros(N,N);                            %%先定义一个N乘N的零矩阵
    for x1=1:N                                   %%x1先从1到N循环
        for y1=1:N                               %%y1再从1到N循环
            s1=s/N;                              %%s1是标准化后的当前s值
            s2=[x1/N,y1/N];                      %%s2是和s1同格式的循环中的，即位置标准化后的值
            delta=0;
            dis=norm(s1-s2);                     %%dis为标准化后两者的距离
            tempA(x1,y1)=dis;                    %%将距离dis赋值给tempA矩阵的对应位置项
            while dis>0.000001
                [s1,dismove]=nextstep(s1,s2,stepdis);
                dis=dis-dismove;
                delta=delta+dismove*E(ceil(s1(1)*N2),ceil(s1(2)*N2));
            end
            tempA(x1,y1)=K*delta+tempA(x1,y1);
        end
    end
end